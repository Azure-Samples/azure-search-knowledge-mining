import logging
import io
import json

from __app__.SharedCode.predict import initialize, predict_image

import azure.functions as func

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    try:
        fileName = req.params.get('filename')
        if not fileName:
            try:
                req_body = req.get_json()
            except ValueError:
                pass
            else:
                fileName = req_body.get('filename')

        if not fileName:
            raise Exception('You must pass in filename for processing.')

        containerName = req.params.get('containername')
        if not containerName:
            try:
                req_body = req.get_json()
            except ValueError:
                pass
            else:
                name = req_body.get('containername')

        if not containerName:
            raise Exception('You must pass in containername for processing.')

        modelname = req.params.get('modelname')
        if not modelname:
            try:
                req_body = req.get_json()
            except ValueError:
                pass
            else:
                name = req_body.get('modelname')

        if not modelname:
            raise Exception('You must pass in modelname for processing.')

        initialize(modelname)

        results = predict_image(fileName, containerName, modelname)
        return write_http_response(200, results) 
    except Exception as e:
        logging.error(str(e))
        return write_http_response(500, str(e))

def write_http_response(status, body_dict):
    return_dict = {
        "status": status,
        "body": json.dumps(body_dict),
        "headers": {
            "Content-Type": "application/json"
        }
    }
    return json.dumps(return_dict)