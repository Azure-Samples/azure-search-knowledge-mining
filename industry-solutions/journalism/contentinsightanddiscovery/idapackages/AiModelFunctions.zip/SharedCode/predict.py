import sys
import tensorflow as tf
import numpy as np
from PIL import Image
from datetime import datetime
from __app__.SharedCode.object_detection import ObjectDetection
import os
import logging
import io

from azure.storage.blob import (
    BlockBlobService
)

_AZURE_STORAGE_CONN_STRING_ENV_NAME = "AzureStorageConnectionString"
_AZURE_MODEL_CONTAINER_NAME = "ModelContainerName"

connString = os.environ[_AZURE_STORAGE_CONN_STRING_ENV_NAME]
modelContainer = os.environ[_AZURE_MODEL_CONTAINER_NAME]

od_dictionary = dict()

class TFObjectDetection(ObjectDetection):
    """Object Detection class for TensorFlow
    """
    def __init__(self, graph_def, labels):
        super(TFObjectDetection, self).__init__(labels)
        self.graph = tf.Graph()
        with self.graph.as_default():
            input_data = tf.placeholder(tf.float32, [1, None, None, 3], name='Placeholder')
            tf.import_graph_def(graph_def, input_map={"Placeholder:0": input_data}, name="")
    def predict(self, preprocessed_image):
        inputs = np.array(preprocessed_image, dtype=np.float)[:, :, (2, 1, 0)] # RGB -> BGR
        with tf.Session(graph=self.graph) as sess:
            output_tensor = sess.graph.get_tensor_by_name('model_outputs:0')
            outputs = sess.run(output_tensor, {'Placeholder:0': inputs[np.newaxis, ...]})
        return outputs[0]

def initialize(modelname):
    logging.info('Loading model...')
    global od_dictionary

    if modelname not in od_dictionary:
        storage_account, storage_key = get_account_name_and_key()

        blobService = BlockBlobService(account_name=storage_account, account_key=storage_key)

        with io.BytesIO() as modelFile:
            blobService.get_blob_to_stream(modelContainer + "/ObjectDetection", modelname, modelFile)
            modelFile.seek(0)
            graph_def = tf.GraphDef()
            graph_def.ParseFromString(modelFile.read())
            logging.info('Success!')

        logging.info('Loading labels...')

        with io.BytesIO() as labelsFile:
            blobService.get_blob_to_stream(modelContainer + "/ObjectDetection", modelname + ".txt", labelsFile)
            labelsFile.seek(0)
            wrapper = io.TextIOWrapper(labelsFile, encoding='utf-8')
            labels = [l.strip() for l in wrapper.readlines()]
            logging.info("{} found. Success!".format(len(labels)))
        
        localod_model = TFObjectDetection(graph_def, labels)
        od_dictionary[modelname] = localod_model
    
def predict_image(fileName, containerName, modelname):
    logging.info('Predicting image')
    localod_model = od_dictionary[modelname]

    storage_account, storage_key = get_account_name_and_key()

    blobService = BlockBlobService(account_name=storage_account, account_key=storage_key)
    with io.BytesIO() as imageFile:
        blobService.get_blob_to_stream(containerName, fileName, imageFile)
        imageFile.seek(0)
        img = Image.open(imageFile)

        w, h = img.size
        logging.info("Image size: {}x{}".format(w, h))

        predictions = localod_model.predict_image(img)

        response = {
            'id': '',
            'project': '',
            'iteration': '',
            'created': datetime.utcnow().isoformat(),
            'predictions': predictions }
            
        logging.info('Results: ' + str(response))
        return response

def get_account_name_and_key():
    ll = connString.split(';')
    for l in ll:
        ss = l.split('=',1)
        if len(ss) != 2:
            continue
        if ss[0] == 'AccountName':
            storage_account = ss[1] 
        if ss[0] == 'AccountKey':
            storage_key = ss[1] 
    if not storage_account or not storage_key:
        raise Exception('Function configuration error: NO Azure Storage connection string found!')

    return storage_account, storage_key

