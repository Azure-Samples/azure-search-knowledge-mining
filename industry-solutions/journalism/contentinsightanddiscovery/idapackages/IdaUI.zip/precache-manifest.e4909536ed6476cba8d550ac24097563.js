self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "1c6912d9c3908f36c5bc",
    "url": "/css/app.c0ca4fb7.css"
  },
  {
    "revision": "1c6912d9c3908f36c5bc",
    "url": "/css/app.c0ca4fb7.css.map"
  },
  {
    "revision": "a1f0765956db81932cb3",
    "url": "/css/chunk-vendors.34967264.css"
  },
  {
    "revision": "a1f0765956db81932cb3",
    "url": "/css/chunk-vendors.34967264.css.map"
  },
  {
    "revision": "87023b8fb8b3555354fe",
    "url": "/css/datasets.0e4ac10b.css"
  },
  {
    "revision": "87023b8fb8b3555354fe",
    "url": "/css/datasets.0e4ac10b.css.map"
  },
  {
    "revision": "f5ba95686cc2da010a66",
    "url": "/css/datasetsDetail~documentDetail~portfoliosDetail.c464db96.css"
  },
  {
    "revision": "f5ba95686cc2da010a66",
    "url": "/css/datasetsDetail~documentDetail~portfoliosDetail.c464db96.css.map"
  },
  {
    "revision": "078c20792b4aed02a6b2",
    "url": "/css/datasetsDetail~portfoliosDetail.b81af655.css"
  },
  {
    "revision": "078c20792b4aed02a6b2",
    "url": "/css/datasetsDetail~portfoliosDetail.b81af655.css.map"
  },
  {
    "revision": "271de692fb21565bd554",
    "url": "/css/datasetsDetail~search.2d17219d.css"
  },
  {
    "revision": "271de692fb21565bd554",
    "url": "/css/datasetsDetail~search.2d17219d.css.map"
  },
  {
    "revision": "ec359e0018f7f76fb672",
    "url": "/css/datasetsUpload.cd919a6f.css"
  },
  {
    "revision": "ec359e0018f7f76fb672",
    "url": "/css/datasetsUpload.cd919a6f.css.map"
  },
  {
    "revision": "4dfd9d3d5c8584a1b2c3",
    "url": "/css/documentDetail.55f3955a.css"
  },
  {
    "revision": "4dfd9d3d5c8584a1b2c3",
    "url": "/css/documentDetail.55f3955a.css.map"
  },
  {
    "revision": "49d828818d14a584d185",
    "url": "/css/documentDetail~search.9ef852f3.css"
  },
  {
    "revision": "49d828818d14a584d185",
    "url": "/css/documentDetail~search.9ef852f3.css.map"
  },
  {
    "revision": "d5dd3a4031e71f3d3c9e",
    "url": "/css/error.86068668.css"
  },
  {
    "revision": "d5dd3a4031e71f3d3c9e",
    "url": "/css/error.86068668.css.map"
  },
  {
    "revision": "0778a32872384ab35323",
    "url": "/css/login.0c61cf90.css"
  },
  {
    "revision": "0778a32872384ab35323",
    "url": "/css/login.0c61cf90.css.map"
  },
  {
    "revision": "bc36f4bb06ea78871ebf",
    "url": "/css/loginGuest.1f40b296.css"
  },
  {
    "revision": "bc36f4bb06ea78871ebf",
    "url": "/css/loginGuest.1f40b296.css.map"
  },
  {
    "revision": "ce840cd3a61fd98b5bc8",
    "url": "/css/portfolios.b2708da5.css"
  },
  {
    "revision": "ce840cd3a61fd98b5bc8",
    "url": "/css/portfolios.b2708da5.css.map"
  },
  {
    "revision": "d99fc434aab329a6fe3a",
    "url": "/css/register.89b1f222.css"
  },
  {
    "revision": "d99fc434aab329a6fe3a",
    "url": "/css/register.89b1f222.css.map"
  },
  {
    "revision": "46f9b0c8be54b1c42c7e",
    "url": "/css/reportViewer.05d256a4.css"
  },
  {
    "revision": "46f9b0c8be54b1c42c7e",
    "url": "/css/reportViewer.05d256a4.css.map"
  },
  {
    "revision": "42be2e40e8828da54d11",
    "url": "/css/scan.902f00d7.css"
  },
  {
    "revision": "42be2e40e8828da54d11",
    "url": "/css/scan.902f00d7.css.map"
  },
  {
    "revision": "47d20f8fe43b573916ac",
    "url": "/css/search-recent.62fbf85b.css"
  },
  {
    "revision": "47d20f8fe43b573916ac",
    "url": "/css/search-recent.62fbf85b.css.map"
  },
  {
    "revision": "819ba3bfc9800886624a",
    "url": "/css/search-saved.b64bf8d3.css"
  },
  {
    "revision": "819ba3bfc9800886624a",
    "url": "/css/search-saved.b64bf8d3.css.map"
  },
  {
    "revision": "a12450319b1cbdbad9d3",
    "url": "/css/search.39cbf925.css"
  },
  {
    "revision": "a12450319b1cbdbad9d3",
    "url": "/css/search.39cbf925.css.map"
  },
  {
    "revision": "bd141dafcdabf455b4a1",
    "url": "/css/users.cf6ece57.css"
  },
  {
    "revision": "bd141dafcdabf455b4a1",
    "url": "/css/users.cf6ece57.css.map"
  },
  {
    "revision": "6b4c4e7cf591ae7eeafc",
    "url": "/css/videoDetail.89230ff0.css"
  },
  {
    "revision": "6b4c4e7cf591ae7eeafc",
    "url": "/css/videoDetail.89230ff0.css.map"
  },
  {
    "revision": "e0d68b0a11419450769fb71e846a5f1e",
    "url": "/favicon.ico"
  },
  {
    "revision": "0509ab09c1b0d2200a4135803c91d6ce",
    "url": "/fonts/MaterialIcons-Regular.0509ab09.woff2"
  },
  {
    "revision": "29b882f018fa6fe75fd338aaae6235b8",
    "url": "/fonts/MaterialIcons-Regular.29b882f0.woff"
  },
  {
    "revision": "96c476804d7a788cc1c05351b287ee41",
    "url": "/fonts/MaterialIcons-Regular.96c47680.eot"
  },
  {
    "revision": "da4ea5cdfca6b3baab285741f5ccb59f",
    "url": "/fonts/MaterialIcons-Regular.da4ea5cd.ttf"
  },
  {
    "revision": "06147b6cd88c7346cecd1edd060cd5de",
    "url": "/fonts/fa-brands-400.06147b6c.ttf"
  },
  {
    "revision": "5063b105c7646c8043d58c5289f02cca",
    "url": "/fonts/fa-brands-400.5063b105.eot"
  },
  {
    "revision": "c5e0f14f88a828261ba01558ce2bf26f",
    "url": "/fonts/fa-brands-400.c5e0f14f.woff"
  },
  {
    "revision": "cccc9d29470e879e40eb70249d9a2705",
    "url": "/fonts/fa-brands-400.cccc9d29.woff2"
  },
  {
    "revision": "65b286af947c0d982ca01b40e1fcab38",
    "url": "/fonts/fa-regular-400.65b286af.ttf"
  },
  {
    "revision": "c1a866ec0e04a5e1915b41fcf261457c",
    "url": "/fonts/fa-regular-400.c1a866ec.eot"
  },
  {
    "revision": "c4f508e7c4f01a9eeba7f08155cde04e",
    "url": "/fonts/fa-regular-400.c4f508e7.woff"
  },
  {
    "revision": "f5f2566b93e89391da4db79462b8078b",
    "url": "/fonts/fa-regular-400.f5f2566b.woff2"
  },
  {
    "revision": "0bff33a5fd7ec390235476b4859747a0",
    "url": "/fonts/fa-solid-900.0bff33a5.ttf"
  },
  {
    "revision": "333bae208dc363746961b234ff6c2500",
    "url": "/fonts/fa-solid-900.333bae20.woff"
  },
  {
    "revision": "44d537ab79f921fde5a28b2c1636f397",
    "url": "/fonts/fa-solid-900.44d537ab.woff2"
  },
  {
    "revision": "8e4a6dcc692b3887f9f542cd6894d6d4",
    "url": "/fonts/fa-solid-900.8e4a6dcc.eot"
  },
  {
    "revision": "c16f5e75532ba308f402ca6429a6344e",
    "url": "/img/clouds.jpg"
  },
  {
    "revision": "e0db4759efb101f133efd387ca96a48a",
    "url": "/img/cohen-docs.jpg"
  },
  {
    "revision": "a9c4bb7348f42626454c988dbde1d0a0",
    "url": "/img/fa-brands-400.a9c4bb73.svg"
  },
  {
    "revision": "7b9568e6389b1f8ae0902cd39665fc1e",
    "url": "/img/fa-regular-400.7b9568e6.svg"
  },
  {
    "revision": "c2801fb415f03c7b170934769d7b5397",
    "url": "/img/fa-solid-900.c2801fb4.svg"
  },
  {
    "revision": "83e889a711070bf09b29aa7a5aa1c023",
    "url": "/img/green-new-deal.jpg"
  },
  {
    "revision": "a2ce523c2543031216e087401b2c3533",
    "url": "/img/holly-springs-ms.jpg"
  },
  {
    "revision": "56675bc2ae9312fed80092ca77956c3d",
    "url": "/img/icons/android-chrome-192x192.png"
  },
  {
    "revision": "4e38da129ddda8eaea3e993d7e2397a7",
    "url": "/img/icons/android-chrome-512x512.png"
  },
  {
    "revision": "d643dcfd047626d9b5810990a699e9c5",
    "url": "/img/icons/apple-touch-icon.png"
  },
  {
    "revision": "347f291d15bec2a343675a229481549d",
    "url": "/img/icons/azure.jpg"
  },
  {
    "revision": "aae3669a397c3d58fdb2460e7f636b2a",
    "url": "/img/icons/facebook.jpg"
  },
  {
    "revision": "c82f278e10c2c9055b77b6a0be84d32b",
    "url": "/img/icons/favicon-16x16.png"
  },
  {
    "revision": "4e96b823792e9d1ce5fac694b265d4c8",
    "url": "/img/icons/favicon-32x32.png"
  },
  {
    "revision": "8f47cb5503591732d8951a973ba1e945",
    "url": "/img/icons/google.jpg"
  },
  {
    "revision": "42b663bd211e49e49b5b964787cecb56",
    "url": "/img/icons/microsoft.jpg"
  },
  {
    "revision": "5af6f22e74dc98d27fa8b80d46edaac1",
    "url": "/img/icons/twitter.jpg"
  },
  {
    "revision": "9ce9c3d60e88211694ebf62ae1c0eb34",
    "url": "/img/kav-emails.jpg"
  },
  {
    "revision": "12a7f8be8f1a7b93edc2dc11a707916a",
    "url": "/img/microsoft-logo.png"
  },
  {
    "revision": "b0d8cb0f562c3797d51e1c1c89987dc4",
    "url": "/img/register.jpg"
  },
  {
    "revision": "e0876d5a98c7344d731eb56c19947df3",
    "url": "/img/saudi-arabia.jpg"
  },
  {
    "revision": "5bd7276de0e2f8297aa1fad039de158f",
    "url": "/index.html"
  },
  {
    "revision": "b3d90b1c4bb5fccf50b8",
    "url": "/js/account.dc8442b5.js"
  },
  {
    "revision": "b3d90b1c4bb5fccf50b8",
    "url": "/js/account.dc8442b5.js.map"
  },
  {
    "revision": "1c6912d9c3908f36c5bc",
    "url": "/js/app.7f896078.js"
  },
  {
    "revision": "1c6912d9c3908f36c5bc",
    "url": "/js/app.7f896078.js.map"
  },
  {
    "revision": "a1f0765956db81932cb3",
    "url": "/js/chunk-vendors.fcddc357.js"
  },
  {
    "revision": "a1f0765956db81932cb3",
    "url": "/js/chunk-vendors.fcddc357.js.map"
  },
  {
    "revision": "87023b8fb8b3555354fe",
    "url": "/js/datasets.b685da1a.js"
  },
  {
    "revision": "87023b8fb8b3555354fe",
    "url": "/js/datasets.b685da1a.js.map"
  },
  {
    "revision": "c38744c7067a78a41cc5",
    "url": "/js/datasetsCreate.c0bd4d86.js"
  },
  {
    "revision": "c38744c7067a78a41cc5",
    "url": "/js/datasetsCreate.c0bd4d86.js.map"
  },
  {
    "revision": "4f6eb5409ec677dd0c89",
    "url": "/js/datasetsDetail.a0c7a6d1.js"
  },
  {
    "revision": "4f6eb5409ec677dd0c89",
    "url": "/js/datasetsDetail.a0c7a6d1.js.map"
  },
  {
    "revision": "f5ba95686cc2da010a66",
    "url": "/js/datasetsDetail~documentDetail~portfoliosDetail.3ac13e1d.js"
  },
  {
    "revision": "f5ba95686cc2da010a66",
    "url": "/js/datasetsDetail~documentDetail~portfoliosDetail.3ac13e1d.js.map"
  },
  {
    "revision": "078c20792b4aed02a6b2",
    "url": "/js/datasetsDetail~portfoliosDetail.378d05ee.js"
  },
  {
    "revision": "078c20792b4aed02a6b2",
    "url": "/js/datasetsDetail~portfoliosDetail.378d05ee.js.map"
  },
  {
    "revision": "271de692fb21565bd554",
    "url": "/js/datasetsDetail~search.e02f339e.js"
  },
  {
    "revision": "271de692fb21565bd554",
    "url": "/js/datasetsDetail~search.e02f339e.js.map"
  },
  {
    "revision": "ec359e0018f7f76fb672",
    "url": "/js/datasetsUpload.19b73dc9.js"
  },
  {
    "revision": "ec359e0018f7f76fb672",
    "url": "/js/datasetsUpload.19b73dc9.js.map"
  },
  {
    "revision": "4dfd9d3d5c8584a1b2c3",
    "url": "/js/documentDetail.f5e8f3b7.js"
  },
  {
    "revision": "4dfd9d3d5c8584a1b2c3",
    "url": "/js/documentDetail.f5e8f3b7.js.map"
  },
  {
    "revision": "49d828818d14a584d185",
    "url": "/js/documentDetail~search.dd522080.js"
  },
  {
    "revision": "49d828818d14a584d185",
    "url": "/js/documentDetail~search.dd522080.js.map"
  },
  {
    "revision": "d5dd3a4031e71f3d3c9e",
    "url": "/js/error.12691dc4.js"
  },
  {
    "revision": "d5dd3a4031e71f3d3c9e",
    "url": "/js/error.12691dc4.js.map"
  },
  {
    "revision": "0778a32872384ab35323",
    "url": "/js/login.81c31c94.js"
  },
  {
    "revision": "0778a32872384ab35323",
    "url": "/js/login.81c31c94.js.map"
  },
  {
    "revision": "bc36f4bb06ea78871ebf",
    "url": "/js/loginGuest.dba26773.js"
  },
  {
    "revision": "bc36f4bb06ea78871ebf",
    "url": "/js/loginGuest.dba26773.js.map"
  },
  {
    "revision": "7fefed69a98d18458c66",
    "url": "/js/loginRedirect.8dac06f6.js"
  },
  {
    "revision": "7fefed69a98d18458c66",
    "url": "/js/loginRedirect.8dac06f6.js.map"
  },
  {
    "revision": "fe9030377ed86c6197d4",
    "url": "/js/notfound.9d5046cc.js"
  },
  {
    "revision": "fe9030377ed86c6197d4",
    "url": "/js/notfound.9d5046cc.js.map"
  },
  {
    "revision": "ce840cd3a61fd98b5bc8",
    "url": "/js/portfolios.65ff0fa9.js"
  },
  {
    "revision": "ce840cd3a61fd98b5bc8",
    "url": "/js/portfolios.65ff0fa9.js.map"
  },
  {
    "revision": "668369065f6656a722e8",
    "url": "/js/portfoliosDetail.7db68557.js"
  },
  {
    "revision": "668369065f6656a722e8",
    "url": "/js/portfoliosDetail.7db68557.js.map"
  },
  {
    "revision": "d99fc434aab329a6fe3a",
    "url": "/js/register.3570ccbf.js"
  },
  {
    "revision": "d99fc434aab329a6fe3a",
    "url": "/js/register.3570ccbf.js.map"
  },
  {
    "revision": "46f9b0c8be54b1c42c7e",
    "url": "/js/reportViewer.56eb3b8e.js"
  },
  {
    "revision": "46f9b0c8be54b1c42c7e",
    "url": "/js/reportViewer.56eb3b8e.js.map"
  },
  {
    "revision": "edadf79264dc4d7822bb",
    "url": "/js/reports.f03bb093.js"
  },
  {
    "revision": "edadf79264dc4d7822bb",
    "url": "/js/reports.f03bb093.js.map"
  },
  {
    "revision": "42be2e40e8828da54d11",
    "url": "/js/scan.db02951f.js"
  },
  {
    "revision": "42be2e40e8828da54d11",
    "url": "/js/scan.db02951f.js.map"
  },
  {
    "revision": "47d20f8fe43b573916ac",
    "url": "/js/search-recent.adbfae73.js"
  },
  {
    "revision": "47d20f8fe43b573916ac",
    "url": "/js/search-recent.adbfae73.js.map"
  },
  {
    "revision": "819ba3bfc9800886624a",
    "url": "/js/search-saved.4797deb0.js"
  },
  {
    "revision": "819ba3bfc9800886624a",
    "url": "/js/search-saved.4797deb0.js.map"
  },
  {
    "revision": "a12450319b1cbdbad9d3",
    "url": "/js/search.6af4fe6a.js"
  },
  {
    "revision": "a12450319b1cbdbad9d3",
    "url": "/js/search.6af4fe6a.js.map"
  },
  {
    "revision": "bd141dafcdabf455b4a1",
    "url": "/js/users.2ae8cd25.js"
  },
  {
    "revision": "bd141dafcdabf455b4a1",
    "url": "/js/users.2ae8cd25.js.map"
  },
  {
    "revision": "6b4c4e7cf591ae7eeafc",
    "url": "/js/videoDetail.7203dd6b.js"
  },
  {
    "revision": "6b4c4e7cf591ae7eeafc",
    "url": "/js/videoDetail.7203dd6b.js.map"
  },
  {
    "revision": "8ab952f77f88290656a8fc13a534beac",
    "url": "/manifest.json"
  },
  {
    "revision": "025403f09bb7ddbeecc9b905902f6e01",
    "url": "/static/world-110m.json"
  }
]);