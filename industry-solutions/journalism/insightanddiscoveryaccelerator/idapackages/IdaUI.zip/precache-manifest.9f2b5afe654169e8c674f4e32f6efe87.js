self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "aa748cca96995e44b37c",
    "url": "/css/app.06deb8a7.css"
  },
  {
    "revision": "aa748cca96995e44b37c",
    "url": "/css/app.06deb8a7.css.map"
  },
  {
    "revision": "1eb6aea47b03efca2c11",
    "url": "/css/chunk-vendors.1c4eae6d.css"
  },
  {
    "revision": "1eb6aea47b03efca2c11",
    "url": "/css/chunk-vendors.1c4eae6d.css.map"
  },
  {
    "revision": "0d9ff7a70b322aff0b8e",
    "url": "/css/datasets.218d458a.css"
  },
  {
    "revision": "0d9ff7a70b322aff0b8e",
    "url": "/css/datasets.218d458a.css.map"
  },
  {
    "revision": "3424581323a6cffa7d37",
    "url": "/css/datasetsDetail~documentDetail~portfoliosDetail.42c4f9bf.css"
  },
  {
    "revision": "3424581323a6cffa7d37",
    "url": "/css/datasetsDetail~documentDetail~portfoliosDetail.42c4f9bf.css.map"
  },
  {
    "revision": "f3ccb3ec300f130165d6",
    "url": "/css/datasetsDetail~portfoliosDetail.f7898369.css"
  },
  {
    "revision": "f3ccb3ec300f130165d6",
    "url": "/css/datasetsDetail~portfoliosDetail.f7898369.css.map"
  },
  {
    "revision": "ce82cb35ff50969ddcef",
    "url": "/css/datasetsDetail~search.2d17219d.css"
  },
  {
    "revision": "ce82cb35ff50969ddcef",
    "url": "/css/datasetsDetail~search.2d17219d.css.map"
  },
  {
    "revision": "adb7993fef66b1f4ad60",
    "url": "/css/datasetsUpload.c478bb87.css"
  },
  {
    "revision": "adb7993fef66b1f4ad60",
    "url": "/css/datasetsUpload.c478bb87.css.map"
  },
  {
    "revision": "67f8bdd9f06340664d04",
    "url": "/css/documentDetail.db9ce50e.css"
  },
  {
    "revision": "67f8bdd9f06340664d04",
    "url": "/css/documentDetail.db9ce50e.css.map"
  },
  {
    "revision": "bb0dd634e6972107654b",
    "url": "/css/documentDetail~search.f303fcb5.css"
  },
  {
    "revision": "bb0dd634e6972107654b",
    "url": "/css/documentDetail~search.f303fcb5.css.map"
  },
  {
    "revision": "40eb7a0fb8cb74740bf1",
    "url": "/css/error.86068668.css"
  },
  {
    "revision": "40eb7a0fb8cb74740bf1",
    "url": "/css/error.86068668.css.map"
  },
  {
    "revision": "c50a1b00945b1395f1b7",
    "url": "/css/login.83bdb917.css"
  },
  {
    "revision": "c50a1b00945b1395f1b7",
    "url": "/css/login.83bdb917.css.map"
  },
  {
    "revision": "9670d445ae6756a22edd",
    "url": "/css/loginGuest.912fcda4.css"
  },
  {
    "revision": "9670d445ae6756a22edd",
    "url": "/css/loginGuest.912fcda4.css.map"
  },
  {
    "revision": "d93573fa47823d2f76e2",
    "url": "/css/portfolios.b2708da5.css"
  },
  {
    "revision": "d93573fa47823d2f76e2",
    "url": "/css/portfolios.b2708da5.css.map"
  },
  {
    "revision": "132eec77861f9a16a380",
    "url": "/css/register.89b1f222.css"
  },
  {
    "revision": "132eec77861f9a16a380",
    "url": "/css/register.89b1f222.css.map"
  },
  {
    "revision": "d32a01dfb5ac4d7265cd",
    "url": "/css/reportViewer.05d256a4.css"
  },
  {
    "revision": "d32a01dfb5ac4d7265cd",
    "url": "/css/reportViewer.05d256a4.css.map"
  },
  {
    "revision": "28c8f9b6fdfdf11d0f46",
    "url": "/css/scan.902f00d7.css"
  },
  {
    "revision": "28c8f9b6fdfdf11d0f46",
    "url": "/css/scan.902f00d7.css.map"
  },
  {
    "revision": "d060a122bdb7d51dd92c",
    "url": "/css/search-recent.ce042def.css"
  },
  {
    "revision": "d060a122bdb7d51dd92c",
    "url": "/css/search-recent.ce042def.css.map"
  },
  {
    "revision": "f01a6b8860091fd3cfa4",
    "url": "/css/search-saved.b64bf8d3.css"
  },
  {
    "revision": "f01a6b8860091fd3cfa4",
    "url": "/css/search-saved.b64bf8d3.css.map"
  },
  {
    "revision": "b9bc1baf4d6e7c1efbb4",
    "url": "/css/search.2bd50a8d.css"
  },
  {
    "revision": "b9bc1baf4d6e7c1efbb4",
    "url": "/css/search.2bd50a8d.css.map"
  },
  {
    "revision": "2c2477dfb9dabd7f32e1",
    "url": "/css/users.cf6ece57.css"
  },
  {
    "revision": "2c2477dfb9dabd7f32e1",
    "url": "/css/users.cf6ece57.css.map"
  },
  {
    "revision": "9b240586aa89b5647a35",
    "url": "/css/videoDetail.0ce0a0ac.css"
  },
  {
    "revision": "9b240586aa89b5647a35",
    "url": "/css/videoDetail.0ce0a0ac.css.map"
  },
  {
    "revision": "e0d68b0a11419450769fb71e846a5f1e",
    "url": "/favicon.ico"
  },
  {
    "revision": "0509ab09c1b0d2200a4135803c91d6ce",
    "url": "/fonts/MaterialIcons-Regular.0509ab09.woff2"
  },
  {
    "revision": "29b882f018fa6fe75fd338aaae6235b8",
    "url": "/fonts/MaterialIcons-Regular.29b882f0.woff"
  },
  {
    "revision": "96c476804d7a788cc1c05351b287ee41",
    "url": "/fonts/MaterialIcons-Regular.96c47680.eot"
  },
  {
    "revision": "da4ea5cdfca6b3baab285741f5ccb59f",
    "url": "/fonts/MaterialIcons-Regular.da4ea5cd.ttf"
  },
  {
    "revision": "06147b6cd88c7346cecd1edd060cd5de",
    "url": "/fonts/fa-brands-400.06147b6c.ttf"
  },
  {
    "revision": "5063b105c7646c8043d58c5289f02cca",
    "url": "/fonts/fa-brands-400.5063b105.eot"
  },
  {
    "revision": "c5e0f14f88a828261ba01558ce2bf26f",
    "url": "/fonts/fa-brands-400.c5e0f14f.woff"
  },
  {
    "revision": "cccc9d29470e879e40eb70249d9a2705",
    "url": "/fonts/fa-brands-400.cccc9d29.woff2"
  },
  {
    "revision": "65b286af947c0d982ca01b40e1fcab38",
    "url": "/fonts/fa-regular-400.65b286af.ttf"
  },
  {
    "revision": "c1a866ec0e04a5e1915b41fcf261457c",
    "url": "/fonts/fa-regular-400.c1a866ec.eot"
  },
  {
    "revision": "c4f508e7c4f01a9eeba7f08155cde04e",
    "url": "/fonts/fa-regular-400.c4f508e7.woff"
  },
  {
    "revision": "f5f2566b93e89391da4db79462b8078b",
    "url": "/fonts/fa-regular-400.f5f2566b.woff2"
  },
  {
    "revision": "0bff33a5fd7ec390235476b4859747a0",
    "url": "/fonts/fa-solid-900.0bff33a5.ttf"
  },
  {
    "revision": "333bae208dc363746961b234ff6c2500",
    "url": "/fonts/fa-solid-900.333bae20.woff"
  },
  {
    "revision": "44d537ab79f921fde5a28b2c1636f397",
    "url": "/fonts/fa-solid-900.44d537ab.woff2"
  },
  {
    "revision": "8e4a6dcc692b3887f9f542cd6894d6d4",
    "url": "/fonts/fa-solid-900.8e4a6dcc.eot"
  },
  {
    "revision": "c16f5e75532ba308f402ca6429a6344e",
    "url": "/img/backgrounds/clouds.jpg"
  },
  {
    "revision": "b0d8cb0f562c3797d51e1c1c89987dc4",
    "url": "/img/backgrounds/newspapers.jpg"
  },
  {
    "revision": "a9c4bb7348f42626454c988dbde1d0a0",
    "url": "/img/fa-brands-400.a9c4bb73.svg"
  },
  {
    "revision": "7b9568e6389b1f8ae0902cd39665fc1e",
    "url": "/img/fa-regular-400.7b9568e6.svg"
  },
  {
    "revision": "c2801fb415f03c7b170934769d7b5397",
    "url": "/img/fa-solid-900.c2801fb4.svg"
  },
  {
    "revision": "56675bc2ae9312fed80092ca77956c3d",
    "url": "/img/icons/android-chrome-192x192.png"
  },
  {
    "revision": "4e38da129ddda8eaea3e993d7e2397a7",
    "url": "/img/icons/android-chrome-512x512.png"
  },
  {
    "revision": "d643dcfd047626d9b5810990a699e9c5",
    "url": "/img/icons/apple-touch-icon.png"
  },
  {
    "revision": "347f291d15bec2a343675a229481549d",
    "url": "/img/icons/azure.jpg"
  },
  {
    "revision": "aae3669a397c3d58fdb2460e7f636b2a",
    "url": "/img/icons/facebook.jpg"
  },
  {
    "revision": "c82f278e10c2c9055b77b6a0be84d32b",
    "url": "/img/icons/favicon-16x16.png"
  },
  {
    "revision": "4e96b823792e9d1ce5fac694b265d4c8",
    "url": "/img/icons/favicon-32x32.png"
  },
  {
    "revision": "8f47cb5503591732d8951a973ba1e945",
    "url": "/img/icons/google.jpg"
  },
  {
    "revision": "42b663bd211e49e49b5b964787cecb56",
    "url": "/img/icons/microsoft.jpg"
  },
  {
    "revision": "5af6f22e74dc98d27fa8b80d46edaac1",
    "url": "/img/icons/twitter.jpg"
  },
  {
    "revision": "12a7f8be8f1a7b93edc2dc11a707916a",
    "url": "/img/logos/microsoft.png"
  },
  {
    "revision": "7eaf6b912f17628def34a4d8ce74f07c",
    "url": "/img/logos/powered_by_white.png"
  },
  {
    "revision": "4996c8e9d73b9d3bf9a26badb9c2679b",
    "url": "/img/logos/the_atlantic.jpg"
  },
  {
    "revision": "5a5c77e738b293328d0154269ab79d50",
    "url": "/index.html"
  },
  {
    "revision": "ddc3cc0ecfc338513a94",
    "url": "/js/account.e0f85bfa.js"
  },
  {
    "revision": "ddc3cc0ecfc338513a94",
    "url": "/js/account.e0f85bfa.js.map"
  },
  {
    "revision": "aa748cca96995e44b37c",
    "url": "/js/app.1a0cfe4a.js"
  },
  {
    "revision": "aa748cca96995e44b37c",
    "url": "/js/app.1a0cfe4a.js.map"
  },
  {
    "revision": "1eb6aea47b03efca2c11",
    "url": "/js/chunk-vendors.216703d2.js"
  },
  {
    "revision": "1eb6aea47b03efca2c11",
    "url": "/js/chunk-vendors.216703d2.js.map"
  },
  {
    "revision": "0d9ff7a70b322aff0b8e",
    "url": "/js/datasets.5a0a2383.js"
  },
  {
    "revision": "0d9ff7a70b322aff0b8e",
    "url": "/js/datasets.5a0a2383.js.map"
  },
  {
    "revision": "6a93a1732cef1cb45801",
    "url": "/js/datasetsCreate.a977c648.js"
  },
  {
    "revision": "6a93a1732cef1cb45801",
    "url": "/js/datasetsCreate.a977c648.js.map"
  },
  {
    "revision": "6ab699f1cc152ccd4bae",
    "url": "/js/datasetsDetail.9cd38445.js"
  },
  {
    "revision": "6ab699f1cc152ccd4bae",
    "url": "/js/datasetsDetail.9cd38445.js.map"
  },
  {
    "revision": "3424581323a6cffa7d37",
    "url": "/js/datasetsDetail~documentDetail~portfoliosDetail.1e9ac21a.js"
  },
  {
    "revision": "3424581323a6cffa7d37",
    "url": "/js/datasetsDetail~documentDetail~portfoliosDetail.1e9ac21a.js.map"
  },
  {
    "revision": "f3ccb3ec300f130165d6",
    "url": "/js/datasetsDetail~portfoliosDetail.ada3e5fa.js"
  },
  {
    "revision": "f3ccb3ec300f130165d6",
    "url": "/js/datasetsDetail~portfoliosDetail.ada3e5fa.js.map"
  },
  {
    "revision": "ce82cb35ff50969ddcef",
    "url": "/js/datasetsDetail~search.d30c2227.js"
  },
  {
    "revision": "ce82cb35ff50969ddcef",
    "url": "/js/datasetsDetail~search.d30c2227.js.map"
  },
  {
    "revision": "adb7993fef66b1f4ad60",
    "url": "/js/datasetsUpload.93a6da47.js"
  },
  {
    "revision": "adb7993fef66b1f4ad60",
    "url": "/js/datasetsUpload.93a6da47.js.map"
  },
  {
    "revision": "67f8bdd9f06340664d04",
    "url": "/js/documentDetail.522c11b7.js"
  },
  {
    "revision": "67f8bdd9f06340664d04",
    "url": "/js/documentDetail.522c11b7.js.map"
  },
  {
    "revision": "bb0dd634e6972107654b",
    "url": "/js/documentDetail~search.447707c1.js"
  },
  {
    "revision": "bb0dd634e6972107654b",
    "url": "/js/documentDetail~search.447707c1.js.map"
  },
  {
    "revision": "40eb7a0fb8cb74740bf1",
    "url": "/js/error.a94f6286.js"
  },
  {
    "revision": "40eb7a0fb8cb74740bf1",
    "url": "/js/error.a94f6286.js.map"
  },
  {
    "revision": "c50a1b00945b1395f1b7",
    "url": "/js/login.8e326980.js"
  },
  {
    "revision": "c50a1b00945b1395f1b7",
    "url": "/js/login.8e326980.js.map"
  },
  {
    "revision": "9670d445ae6756a22edd",
    "url": "/js/loginGuest.fbfdacb9.js"
  },
  {
    "revision": "9670d445ae6756a22edd",
    "url": "/js/loginGuest.fbfdacb9.js.map"
  },
  {
    "revision": "c85dffe931e47a1dc6ba",
    "url": "/js/loginRedirect.adc51128.js"
  },
  {
    "revision": "c85dffe931e47a1dc6ba",
    "url": "/js/loginRedirect.adc51128.js.map"
  },
  {
    "revision": "c4e86ccac517c626f0ed",
    "url": "/js/notfound.6a2c0b5f.js"
  },
  {
    "revision": "c4e86ccac517c626f0ed",
    "url": "/js/notfound.6a2c0b5f.js.map"
  },
  {
    "revision": "d93573fa47823d2f76e2",
    "url": "/js/portfolios.2e55c6f0.js"
  },
  {
    "revision": "d93573fa47823d2f76e2",
    "url": "/js/portfolios.2e55c6f0.js.map"
  },
  {
    "revision": "64df09434a6cbe8e7084",
    "url": "/js/portfoliosDetail.40c707fc.js"
  },
  {
    "revision": "64df09434a6cbe8e7084",
    "url": "/js/portfoliosDetail.40c707fc.js.map"
  },
  {
    "revision": "132eec77861f9a16a380",
    "url": "/js/register.4c80116c.js"
  },
  {
    "revision": "132eec77861f9a16a380",
    "url": "/js/register.4c80116c.js.map"
  },
  {
    "revision": "d32a01dfb5ac4d7265cd",
    "url": "/js/reportViewer.cee42e38.js"
  },
  {
    "revision": "d32a01dfb5ac4d7265cd",
    "url": "/js/reportViewer.cee42e38.js.map"
  },
  {
    "revision": "1af35eda92b92c4d8fc5",
    "url": "/js/reports.be2ed59b.js"
  },
  {
    "revision": "1af35eda92b92c4d8fc5",
    "url": "/js/reports.be2ed59b.js.map"
  },
  {
    "revision": "28c8f9b6fdfdf11d0f46",
    "url": "/js/scan.110a3a53.js"
  },
  {
    "revision": "28c8f9b6fdfdf11d0f46",
    "url": "/js/scan.110a3a53.js.map"
  },
  {
    "revision": "d060a122bdb7d51dd92c",
    "url": "/js/search-recent.acbbdf24.js"
  },
  {
    "revision": "d060a122bdb7d51dd92c",
    "url": "/js/search-recent.acbbdf24.js.map"
  },
  {
    "revision": "f01a6b8860091fd3cfa4",
    "url": "/js/search-saved.a24cf04f.js"
  },
  {
    "revision": "f01a6b8860091fd3cfa4",
    "url": "/js/search-saved.a24cf04f.js.map"
  },
  {
    "revision": "b9bc1baf4d6e7c1efbb4",
    "url": "/js/search.77a868ba.js"
  },
  {
    "revision": "b9bc1baf4d6e7c1efbb4",
    "url": "/js/search.77a868ba.js.map"
  },
  {
    "revision": "2c2477dfb9dabd7f32e1",
    "url": "/js/users.b239c81e.js"
  },
  {
    "revision": "2c2477dfb9dabd7f32e1",
    "url": "/js/users.b239c81e.js.map"
  },
  {
    "revision": "9b240586aa89b5647a35",
    "url": "/js/videoDetail.47fd7112.js"
  },
  {
    "revision": "9b240586aa89b5647a35",
    "url": "/js/videoDetail.47fd7112.js.map"
  },
  {
    "revision": "8ab952f77f88290656a8fc13a534beac",
    "url": "/manifest.json"
  },
  {
    "revision": "025403f09bb7ddbeecc9b905902f6e01",
    "url": "/static/world-110m.json"
  }
]);